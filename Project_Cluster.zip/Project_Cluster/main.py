# Using unsupervised learning algorithms to Screen Stocks by fundamental financial data

# 1.0     Data Source
# Fundamental stock data was sourced from Nasdaq Data Link (https://data.nasdaq.com/databases/SF1/documentation)
# This is reference grade fundamental stock data, providing up to 10 years of history,
# of over 100 financial indicators and ratios for all companies listed on US stock exchanges

# 2.0    Import the required packages from Python
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import seaborn as sns
from scipy.cluster.vq import whiten, kmeans, vq
from sklearn.decomposition import PCA
from scipy.cluster.hierarchy import linkage, fcluster, dendrogram

# 3.0    Load CSV annual financial data for all companies listed on US exchanges
source_data = pd.read_csv('SHARADAR_all_stocks_selected_features.csv', index_col='ticker', parse_dates=True)
print (source_data.shape)
# There are 58,825 rows and 39 Columns
print (source_data.head())
print (source_data.info())

# 3.1   Financial data for all stocks listed US exchanges are in the source_data DataFrame.
#       We need to filter out stock information for the SNP500 as these are the stocks of interest.
# 3.2   First load CSV of SNP500 tickers and company names
snp_tickers = pd.read_csv('SHARADAR-SP500.csv', index_col = 'ticker')
print (snp_tickers.shape)
# There are 505 rows and 1 Columns
print (snp_tickers.head())
print (snp_tickers.info())
# 3.3   Extract SNP500 stock data from 'source_data' using a merge with 'snp_tickers'
snp500_raw_features = snp_tickers.merge(source_data, how='inner', on='ticker')
print (snp500_raw_features.shape)
print (snp500_raw_features.head())

# 4.0    Data Cleaning
#        snp_features has 4963 rows with 40 columns
# 4.1    Check datatypes are appropriate
print (snp500_raw_features.dtypes) # change 'year' datatype to datetime object
snp500_raw_features['year'] = pd.to_datetime(snp500_raw_features['year'])
print (snp500_raw_features.info()) # OK, year is datetime64

# 4.2    get summary of missing values 'NaN' by column
print (snp500_raw_features.isna().sum())

# 4.3     for 'dividend yield' column replace 'NaN' with 0
snp500_raw_features['divyield'] = snp500_raw_features['divyield'].fillna(0)
print (snp500_raw_features.isna().sum())

# 4.4     drop rows that have 'NaN' in up to 5 columns and check
snp500_raw_features.dropna(thresh=5 , inplace=True)
print (snp500_raw_features.isna().sum())

# 4.5   Drop incomplete features where equivalent alternative features are available
snp500_raw_features.drop(['sharesbas', 'workingcapital', 'currentratio', 'assetsc', 'assetsnc',
                          'liabilitiesc', 'liabilitiesnc', 'debt_current', 'debtnc', 'assetsavg',
                          'payoutratio', 'debtusd'], axis=1, inplace=True )
print (snp500_raw_features.isna().sum())

# 4.4    From the list of columns 'cols', drop rows that have 'NaN' values
cols = ['assets','sales_ps','epsdil','roe']
snp500_raw_features.dropna(subset=cols, inplace=True)
print (snp500_raw_features.isna().sum())
# All NaNs cleaned, 4882 rows and 28 columns remaining
print (snp500_raw_features.shape)

# Check and Clean out-of-range data
print (snp500_raw_features.assets.describe()) #OK
print (snp500_raw_features.liabilities.describe()) #OK

print (snp500_raw_features.gross_margin.describe())
# Some gross margin values are over 1, these rows should be dropped
snp500_raw_features = snp500_raw_features[snp500_raw_features['gross_margin'] < 1]

print (snp500_raw_features.net_margin.describe())
# Some net margin values are over 1, these rows should be dropped
snp500_raw_features = snp500_raw_features[snp500_raw_features['net_margin'] < 1.0]
print (snp500_raw_features.net_margin.describe()) #OK
print (snp500_raw_features.debt_to_equity.describe()) # OK
print (snp500_raw_features.roe.describe()) #OK
print (snp500_raw_features.roic.describe()) #OK

# Export CSV file of raw_features
snp500_raw_features.to_csv('snp500_raw_features.csv')

# 5.0      Feature Engineering
# the features must be converted to a format more suitable for clustering methods (unsupervised learning).
# the stock data is in a small group timeseries, each ticker having about 10 rows, with 1 row per year.
# the time structure of the data must be compressed to 1 row per ticker, with new measures such as
# historical growth and most recent value, depending on the feature of interest.
# Refer to report for more information on feature engineering.
# After the feature engineering phase there are 10 features to describe the financial performance of 495 stocks.

# # compute latest value net margin for each ticker, store in dataframe df1
net_margin = []
for ticker in snp_tickers.index:
    # series object to store asset/liability ratio for each iteration on ticker
    series = snp500_raw_features.loc[ticker, 'net_margin']
    latest_value = series[-1] # identify the most recent value of return on equity (roe)
    net_margin.append(latest_value) # append to list on each iteration
df1 = pd.DataFrame(net_margin, columns=['net_margin'], index=snp_tickers.index)

# compute latest value gross margin for each ticker, store in dataframe df2
gross_margin = []
for ticker in snp_tickers.index:
    # series object to store asset/liability ratio for each iteration on ticker
    series = snp500_raw_features.loc[ticker, 'gross_margin']
    latest_value = series[-1] # identify the most recent value of return on equity (roe)
    gross_margin.append(latest_value) # append to list on each iteration
df2 = pd.DataFrame(gross_margin, columns=['gross_margin'], index=snp_tickers.index)

# compute latest value of return on equity (roe) for each ticker, store in dataframe df3
roe = []
for ticker in snp_tickers.index:
    # series object to store asset/liability ratio for each iteration on ticker
    series = snp500_raw_features.loc[ticker,'roe']
    latest_value = series[-1] # identify the most recent value of return on equity (roe)
    roe.append(latest_value) # append to list on each iteration
df3 = pd.DataFrame(roe, columns=['roe'], index=snp_tickers.index)

# compute latest value of return on invested capital (roic) for each ticker
roic = []
for ticker in snp_tickers.index:
    # series object to store asset/liability ratio for each iteration on ticker
    series = snp500_raw_features.loc[ticker,'roic']
    latest_value = series[-1] # identify the most recent value of return on equity (roe)
    roic.append(latest_value) # append to list on each iteration
df4 = pd.DataFrame(roic, columns=['roic'], index=snp_tickers.index)

# Convert 'debt_to_equity' feature to  'equity_to_debt' by inverting it
snp500_raw_features['equity_to_debt'] = 1 / snp500_raw_features['debt_to_equity']
# compute latest value of equity_to_debt ratio for each ticker
equity_to_debt= []
for ticker in snp_tickers.index:
    # series object to store asset/liability ratio for each iteration on ticker
    series = snp500_raw_features.loc[ticker,'equity_to_debt']
    latest_value = series[-1] # identify the most recent value of return on equity (roe)
    equity_to_debt.append(latest_value) # append to list on each iteration
df5 = pd.DataFrame(equity_to_debt, columns=['equity_to_debt'], index=snp_tickers.index)

# compute latest value of dividend yield for each ticker
divyield = []
for ticker in snp_tickers.index:
    # series object to store asset/liability ratio for each iteration on ticker
    series = snp500_raw_features.loc[ticker,'divyield']
    latest_value = series[-1] # identify the most recent value of return on equity (roe)
    divyield.append(latest_value) # append to list on each iteration
df6 = pd.DataFrame(divyield, columns=['divyield'], index=snp_tickers.index)

# Compute Growth Rates for earnings, sales, cashflow, and book value
# Growth Rates are computed as the average growth rate over 10 years

# Compute Book Value per Share Growth Rates
bvps_growth = []
for ticker in snp_tickers.index:
    series = snp500_raw_features.loc[ticker,'bvps']   # series object to store bvps values for each loop on ticker
    start_value = series[0] # identify the starting value of bvps
    long_term_growth = series[0:-1].div(start_value).mean() #subset all the values, divide by start_date, take mean
    bvps_growth.append(long_term_growth) # append to list on each iteration
# Create dataframe to store the values for each company
df7 = pd.DataFrame(bvps_growth, columns=['bvps_growth'], index = snp_tickers.index)

# Compute Earnings per Share Growth Rates
eps_growth = []
for ticker in snp_tickers.index:
    series = snp500_raw_features.loc[ticker,'earnings_ps']   # series object to store eps values for each loop on ticker
    start_value = series[0] # identify the starting value of eps
    long_term_growth = series[0:-1].div(start_value).mean() #subset all the values, divide by start_date, take mean
    eps_growth.append(long_term_growth) # append to list on each iteration
# Create dataframe to store the values for each company
df8 = pd.DataFrame(eps_growth, columns=['eps_growth'], index = snp_tickers.index)

# Compute Sales revenue per Share Growth Rates
sps_growth = []
for ticker in snp_tickers.index:
    series = snp500_raw_features.loc[ticker,'sales_ps']   # series object to store sales values for each loop on ticker
    start_value = series[0] # identify the starting value of sps
    long_term_growth = series[0:-1].div(start_value).mean() #subset all the values, divide by start_date, take mean
    sps_growth.append(long_term_growth) # append to list on each iteration
# Create dataframe to store the values for each company
df9 = pd.DataFrame(sps_growth, columns=['sps_growth'], index = snp_tickers.index)

# Compute CashFlow from Operations per Share Growth Rates
cashflow_growth = []
# create an 'cashflow_per_share' feature and get the most recent value for each ticker
snp500_raw_features['cashflow_ps'] = snp500_raw_features['ncfo']/snp500_raw_features['shareswa']
for ticker in snp_tickers.index:
    series = snp500_raw_features.loc[ticker,'cashflow_ps']   # series object to store sps values for each loop on ticker
    start_value = series[0] # identify the starting value of sps
    long_term_growth = series[0:-1].div(start_value).mean() #subset all the values, divide by start_date, take mean
    cashflow_growth.append(long_term_growth) # append to list on each iteration
# Create dataframe to store the values for each company
df10 = pd.DataFrame(cashflow_growth, columns=['cashflow_growth'], index = snp_tickers.index)

frames = [snp_tickers,df1,df2,df3,df4,df5,df6,df7,df8,df9,df10]
snp500_new_features = pd.concat(frames, axis=1)
print (snp500_new_features.info())
snp500_new_features.to_csv('snp500_new_features.csv')
# After feature engineering we have:
# 10 new features, each is a financial metric
# 457 observations, each observation for one company
# time-series for each ticker compressed into 1 row
# features describe either long-term growth (10 years) or most recent year value

# 6.0    Exploratory Data Analysis
# 6.1    Create a triangular heatmap of correlation between the features
plt.figure(figsize=(20, 8))
# define the mask to set the values in the upper triangle to True
mask = np.triu(np.ones_like(snp500_new_features.corr(), dtype=bool))
# creating a heatmap of features correlation, using the Seaborn heatmap() function and the corr() method:
heatmap = sns.heatmap(snp500_new_features.corr(), mask=mask, vmin=-1, vmax=1, annot=True, cmap='BrBG')
heatmap.set_title('Correlation between features Heatmap', fontdict={'fontsize':18}, pad=16)
plt.tight_layout()
plt.show()
plt.savefig('Correlation_between_features_HeatMap.jpg')

sns.set_style("dark")
sns.boxplot(data=snp500_new_features).set(title='Boxplot of features inc outliers')
plt.savefig('boxplot_of_features.jpg')
plt.show()
# Remove largest outliers using filtering with a condition
snp500_new_features = snp500_new_features[snp500_new_features['cashflow_growth'] < 56]
snp500_new_features = snp500_new_features[snp500_new_features['eps_growth'] < 133]
snp500_new_features = snp500_new_features[snp500_new_features['bvps_growth'] < 110]
snp500_new_features = snp500_new_features[snp500_new_features['bvps_growth'] > -40]
snp500_new_features = snp500_new_features[snp500_new_features['roe'] < 54]
# Replot box plot without extreme outliers
sns.set_style("dark")
sns.boxplot(data=snp500_new_features).set(title='Boxplot of features w/o outliers')
plt.savefig('boxplot_of_features_without_outliers.jpg')
plt.show()

# 7.0   Data Preparation for Cluster Analysis

# 7.1    Initiate the data as a 2D numpy array
# Create a dataframe of only the feature data
# 7.1.1  Reset index of tickers for dataframe snp_new_features
snp500_dataframe = snp500_new_features.reset_index(drop=True)
# 7.1.2  Drop the 'name' column
snp500_dataframe = snp500_dataframe.drop(['name'], axis=1)
# 7.1.3  Convert snp500_dataframe to numpy array of the data
data = snp500_dataframe.to_numpy()
# 7.1.4  Check shape of numpy array 'data'
print (data.shape) #OK

# 7.2   Scaling the data using MinMaxScaler
# 7.2.1 Scale the feature data by rescaling to a range
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
scaled_samples = scaler.fit_transform(data)
# 7.3   Dimensionality reduction using PCA to estimate intrinsic dimension
# 7.3.1 Create PCA instance: model
model = PCA()
# 7.3.2 Fit the model to the scaled samples
model.fit(scaled_samples)
# 7.3.3 Determine the intrinsic dimension of the 10 dimensional dataset using PCA
# 7.3.3.1  Create a range enumerating the PCA features,
features = range(model.n_components_)
# 7.3.3.2  Make a bar plot of the variances;
# the variances are available as the explained_variance attribute of the PCA model
plt.bar(features, model.explained_variance_)
plt.xticks(features)
plt.xlabel('PCA_feature')
plt.ylabel('Variance')
plt.show()
# 7.4  Estimate of Intrinsic dimension = 3

# 8.0  Reduce Dimensions to the intrinsic dimension of 3 using PCA
# Create a PCA model with 3 components
pca = PCA(n_components=3)
# Fit the PCA instance to the scaled samples
pca.fit(scaled_samples)
# Transform the scaled samples: pca_features
pca_features = pca.transform(scaled_samples)
# Print the shape of pca_features
print(pca_features.shape)
# Dimensions reduced from 10 to 3

# 9.0 Partition based clustering (using K-means algorithm)

# 9.1 Determine K ( No. of clusters) using elbow plot
distortions = []
num_clusters = range(2, 51)
for i in num_clusters:
    centroids, distortion = kmeans(pca_features, i)
    distortions.append(distortion)
# 9.1.2  Plot Elbow Plot
elbow_plot_data = pd.DataFrame({'num_clusters':num_clusters, 'distortions':distortions})
sns.lineplot(x = 'num_clusters', y='distortions', data=elbow_plot_data).set(title='Elbow Plot')
plt.savefig('elbow plot for estimating optimal cluster No. K.jpg')
plt.show()
# 9.1.3  Estimate of optimal K (optimal K = 20 to 30 clusters )

# 9.2   Run K-means
# 9.2.1  Generate cluster centres and labels
cluster_centres, _ = kmeans(pca_features, 20, iter=30, seed=123)
df = pd.DataFrame()
df['cluster_labels'], _ = vq(pca_features, cluster_centres)

# 9.2.2  append cluster labels to snp500_new_features dataframe
#frames = [snp500_new_features, df]
snp500_dataframe = snp500_new_features.reset_index()
cluster_labels = snp500_dataframe.merge(df, left_index=True, right_index=True)
cluster_labels.to_csv('cluster_labels.csv')
cluster_feature_means = cluster_labels.groupby('cluster_labels').mean()
cluster_feature_means.to_csv('k-means_cluster_feature_mean.csv')
print (cluster_labels.groupby('cluster_labels')['ticker'].count())

# 9.3   Visualise clusters using t-SNE
from sklearn.manifold import TSNE
model = TSNE(learning_rate=100)
transformed = model.fit_transform(scaled_samples)
xs = transformed[:,0]
ys = transformed[:,1]
plt.scatter(xs, ys, c=cluster_labels['cluster_labels'])
plt.show()

# 10.0  Agglomerative based clustering (using Hierarchical clustering)

# 10.1  Use the linkage() function to obtain a hierarchical clustering of the stocks
Z = linkage(scaled_samples, method = 'ward', metric = 'euclidean')
tickers = snp500_new_features.index
dn = dendrogram(Z, labels=tickers)
plt.show()

labels = fcluster(Z, 1.25, criterion='distance')
pairs = pd.DataFrame({'labels':labels, 'tickers': tickers})
sorted_labels = (pairs.sort_values('labels'))
print (sorted_labels)
sorted_labels.to_csv('hierarchical_clusters.csv')
